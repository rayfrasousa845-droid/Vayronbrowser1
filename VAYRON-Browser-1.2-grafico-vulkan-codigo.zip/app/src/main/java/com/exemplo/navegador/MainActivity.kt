package com.exemplo.navegador

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.WebView
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebStorage
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    /** Uma aba = um WebView + alguns estados. */
    private class Tab(val webView: WebView) {
        var title: String = "Nova aba"
        var progress: Int = 100
        var desktop: Boolean = false
    }

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null

    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabContainer: LinearLayout
    private lateinit var urlBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var btnBack: TextView
    private lateinit var btnForward: TextView
    private lateinit var btnReload: TextView

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tabScroll = findViewById(R.id.tabScroll)
        tabContainer = findViewById(R.id.tabContainer)
        urlBar = findViewById(R.id.urlBar)
        progressBar = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)

        btnBack.setOnClickListener {
            current?.webView?.let { if (it.canGoBack()) it.goBack() }
        }
        btnForward.setOnClickListener {
            current?.webView?.let { if (it.canGoForward()) it.goForward() }
        }
        btnReload.setOnClickListener {
            val tab = current ?: return@setOnClickListener
            if (tab.progress in 1..99) {
                tab.webView.stopLoading()
                tab.progress = 100
                updateLoading()
            } else {
                tab.webView.reload()
            }
        }
        findViewById<TextView>(R.id.btnNewTab).setOnClickListener { openTab(HOME_URL, true) }
        findViewById<TextView>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlBar.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadFromUrlBar()
                true
            } else {
                false
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val tab = current
                when {
                    customView != null -> hideCustomView()
                    tab != null && tab.webView.canGoBack() -> tab.webView.goBack()
                    tabs.size > 1 && tab != null -> closeTab(tab)
                    else -> finish()
                }
            }
        })

        if (!openFromIntent(intent)) openTab(HOME_URL, true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        openFromIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        tabs.forEach { it.webView.onPause() }
    }

    override fun onResume() {
        super.onResume()
        tabs.forEach { it.webView.onResume() }
    }

    override fun onDestroy() {
        tabs.forEach {
            webContainer.removeView(it.webView)
            it.webView.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- abas

    private fun openFromIntent(i: Intent?): Boolean {
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) {
            openTab(data.toString(), true)
            return true
        }
        return false
    }

    private fun tabFor(view: WebView?): Tab? = tabs.firstOrNull { it.webView === view }

    private fun openTab(url: String?, select: Boolean): Tab {
        val tab = Tab(createWebView())
        tabs.add(tab)
        tab.webView.visibility = View.GONE
        webContainer.addView(tab.webView)
        if (select) selectTab(tab) else refreshTabs()
        if (url != null) tab.webView.loadUrl(url)
        return tab
    }

    private fun selectTab(tab: Tab) {
        current = tab
        tabs.forEach { it.webView.visibility = if (it === tab) View.VISIBLE else View.GONE }
        urlBar.clearFocus()
        updateUrlBar(tab.webView.url)
        updateNav()
        updateLoading()
        refreshTabs()
    }

    private fun closeTab(tab: Tab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)
        webContainer.removeView(tab.webView)
        tab.webView.destroy()

        if (tabs.isEmpty()) {
            current = null
            openTab(HOME_URL, true) // sempre mantém pelo menos uma aba
            return
        }
        if (tab === current) {
            selectTab(tabs[minOf(index, tabs.size - 1)])
        } else {
            refreshTabs()
        }
    }

    private fun refreshTabs() {
        tabContainer.removeAllViews()
        var selectedChip: View? = null

        tabs.forEach { tab ->
            val selected = tab === current
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(if (selected) R.drawable.tab_selected else R.drawable.tab_normal)
                setPadding(dp(12), 0, dp(4), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)
                ).apply { setMargins(dp(4), 0, 0, 0) }
                setOnClickListener { selectTab(tab) }
            }
            val title = TextView(this).apply {
                text = tab.title
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                maxWidth = dp(120)
                textSize = 13f
                setTextColor(getColor(R.color.text))
            }
            val close = TextView(this).apply {
                text = "✕"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(getColor(R.color.muted))
                setPadding(dp(8), dp(4), dp(8), dp(4))
                contentDescription = "Fechar aba"
                setOnClickListener { closeTab(tab) }
            }
            chip.addView(title)
            chip.addView(close)
            tabContainer.addView(chip)
            if (selected) selectedChip = chip
        }

        selectedChip?.let { chip -> tabScroll.post { tabScroll.smoothScrollTo(chip.left - dp(16), 0) } }
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView = WebView(this).apply {
        // Solicita a camada acelerada por hardware; o backend (OpenGL/Vulkan)
        // continua sendo escolhido pelo Android System WebView e pelo driver.
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(true)
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                if (view === current?.webView) updateUrlBar(url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (view === current?.webView) {
                    updateUrlBar(url)
                    updateNav()
                }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (view === current?.webView) updateNav()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return when (request.url.scheme) {
                    "http", "https", "file", "about", "data", "javascript" -> false
                    else -> {
                        // tel:, mailto:, intent:, etc. -> entrega para outro app
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, request.url))
                        } catch (_: Exception) {
                        }
                        true
                    }
                }
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                val tab = tabFor(view) ?: return
                tab.progress = newProgress
                if (tab === current) updateLoading()
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                val tab = tabFor(view) ?: return
                tab.title = if (title.isNullOrBlank()) "Sem título" else title
                refreshTabs()
            }

            // target="_blank" / window.open -> nova aba (popups sem toque do usuário são bloqueados)
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                if (!isUserGesture) return false
                val newTab = openTab(null, true)
                (resultMsg.obj as WebView.WebViewTransport).webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                tabFor(window)?.let { closeTab(it) }
            }

            // vídeo em tela cheia
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                showCustomView(view, callback)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent)
                    CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                    setTitle(fileName)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                (this@MainActivity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this@MainActivity, "Baixando $fileName", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Não foi possível baixar o arquivo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }
        customView = view
        customViewCallback = callback
        view.setBackgroundColor(Color.BLACK)
        (window.decorView as ViewGroup).addView(
            view,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun hideCustomView() {
        val view = customView ?: return
        (window.decorView as ViewGroup).removeView(view)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // ---------------------------------------------------------------- barra de endereço e UI

    private fun resolveInput(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return HOME_URL
        val hasScheme = text.startsWith("http://") || text.startsWith("https://") || text.startsWith("file://")
        if (hasScheme) return text
        val looksLikeAddress = !text.contains(" ") && (text.contains(".") || text.startsWith("localhost"))
        return if (looksLikeAddress) {
            "https://$text"
        } else {
            SEARCH_URL + URLEncoder.encode(text, "UTF-8")
        }
    }

    private fun loadFromUrlBar() {
        val target = resolveInput(urlBar.text.toString())
        val webView = current?.webView ?: return
        webView.loadUrl(target)
        webView.requestFocus()
        urlBar.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    private fun updateUrlBar(url: String?) {
        if (urlBar.hasFocus()) return // não atrapalha quem está digitando
        urlBar.setText(if (url == null || url.startsWith("file:///android_asset")) "" else url)
    }

    private fun updateNav() {
        val webView = current?.webView
        btnBack.alpha = if (webView?.canGoBack() == true) 1f else 0.35f
        btnForward.alpha = if (webView?.canGoForward() == true) 1f else 0.35f
    }

    private fun updateLoading() {
        val progress = current?.progress ?: 100
        val loading = progress in 1..99
        progressBar.progress = progress
        progressBar.visibility = if (loading) View.VISIBLE else View.INVISIBLE
        btnReload.text = if (loading) "✕" else "⟳"
    }

    private fun showMenu(anchor: View) {
        val tab = current ?: return
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Nova aba")
            menu.add(0, 2, 1, "Página inicial")
            menu.add(0, 3, 2, "Compartilhar link")
            menu.add(0, 4, 3, if (tab.desktop) "Versão para celular" else "Versão para computador")
            menu.add(0, 5, 4, "Limpar dados de navegação")
            menu.add(0, 6, 5, "Diagnóstico gráfico / Vulkan")
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> openTab(HOME_URL, true)
                    2 -> tab.webView.loadUrl(HOME_URL)
                    3 -> shareCurrentPage()
                    4 -> toggleDesktopMode(tab)
                    5 -> clearBrowsingData()
                    6 -> showGraphicsDiagnostics()
                }
                true
            }
            show()
        }
    }

    private fun shareCurrentPage() {
        val url = current?.webView?.url ?: return
        if (url.startsWith("file:///android_asset")) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(send, "Compartilhar link"))
    }

    private fun toggleDesktopMode(tab: Tab) {
        tab.desktop = !tab.desktop
        tab.webView.settings.userAgentString = if (tab.desktop) DESKTOP_UA else null
        tab.webView.reload()
    }

    private fun showGraphicsDiagnostics() {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val glVersion = activityManager.deviceConfigurationInfo?.glEsVersion ?: "Não informado"
        val hasVulkanLevel = packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)
        val hasVulkanVersion = packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION)
        val vulkanLevel = if (Build.VERSION.SDK_INT >= 24 && hasVulkanLevel) {
            packageManager.getSystemAvailableFeatures()
                .firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL }
                ?.version?.toString() ?: "Disponível (nível não informado)"
        } else "Não detectado pelo Android"
        val vulkanVersion = if (Build.VERSION.SDK_INT >= 24 && hasVulkanVersion) {
            packageManager.getSystemAvailableFeatures()
                .firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }
                ?.version?.toString() ?: "Disponível (versão não informada)"
        } else "Não detectado pelo Android"
        val webViewVersion = try {
            WebView.getCurrentWebViewPackage()?.versionName ?: "Não identificada"
        } catch (_: Exception) { "Não identificada" }

        val report = """
            Aceleração de hardware: ativada no aplicativo e no WebView
            Renderização do WebView: gerenciada pelo Android System WebView
            Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
            WebView: $webViewVersion
            OpenGL ES suportado: $glVersion
            Vulkan hardware level: $vulkanLevel
            Vulkan hardware version: $vulkanVersion

            IMPORTANTE: esses dados mostram os recursos anunciados pelo Android. O WebView escolhe internamente o backend gráfico; o navegador não consegue obrigar o uso de Vulkan nem confirmar por API pública se uma página específica está sendo renderizada por Vulkan.
        """.trimIndent()

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Diagnóstico gráfico")
            .setMessage(report)
            .setPositiveButton("OK", null)
            .setNeutralButton("Copiar relatório") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Diagnóstico VAYRON", report))
                Toast.makeText(this, "Relatório copiado", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun clearBrowsingData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tabs.forEach {
            it.webView.clearCache(true)
            it.webView.clearHistory()
        }
        updateNav()
        Toast.makeText(this, "Dados de navegação apagados", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val HOME_URL = "file:///android_asset/home.html"
        private const val SEARCH_URL = "https://www.google.com/search?q="
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
    }
}
