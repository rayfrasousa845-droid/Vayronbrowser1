# VAYRON Browser (Android)

Navegador Android em Kotlin com WebView, interface escura roxa e página inicial personalizada.

## Recursos

- Abas múltiplas com indicação visual da aba ativa
- Barra de endereço e pesquisa Google
- Voltar, avançar, recarregar/parar e progresso de carregamento
- Página inicial VAYRON com relógio e atalhos para sites populares
- Menu: nova aba, página inicial, compartilhar link, modo computador e limpar dados
- Downloads pelo gerenciador do Android
- Vídeo em tela cheia
- Pop-ups sem gesto do usuário bloqueados
- Abre links HTTP/HTTPS de outros aplicativos

## Compilar

Requisitos: Android Studio recente e JDK 17.

1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle Sync.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Também há um workflow em `.github/workflows/build-apk.yml` que compila o APK quando há push na branch `main` ou execução manual.

## Identidade do aplicativo

O `applicationId` permanece `com.exemplo.navegador` para preservar a identidade do app. O nome exibido agora é **VAYRON Browser**. A versão do projeto foi atualizada para 1.1.

**Importante sobre atualizações:** APKs assinados com chaves diferentes não podem atualizar um ao outro. O APK de debug gerado automaticamente pelo GitHub pode não ter a mesma assinatura do APK instalado anteriormente; nesse caso, será necessário desinstalar a versão antiga antes de instalar a nova, ou configurar uma chave de assinatura persistente para builds de release.
